
	
#!/bin/bash

#############################################################################
#
# $Id: execute_RasterCalculation.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Creates a new raster by adding, subtracting, multiplying and dividing (bands of) multiple raster images provided that they have the same grid
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Environment Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory (This Folder should contain all the GRASS output files)
# *GENERAL_SERVICES_RESOURCES : Services General Resources Directory (This Folder contains general resources for all Toolbox services ).
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains only the resources of the current service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory (This Folder should contain all the temporaney files)		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)
# *GRASS_LOG_FILE: File path for GRASS text LOG	(This File should contain all GRASS messages)
# *STATUS_FILE: File path for XML Status file (This XML File should contain the status information of the GRASS operation)		
#					 
#					 
# ***************************************************************************************************************************************
		
		
# ********* Input Environment Variables ***************************************************************************************************

# *InputRaster_MULTIPLE_INPUT_FOLDER: (Folder that contains the multiple Complex Value "InputRaster" Input defined by reference in the Execute Request.)
#      (Input Description: Input raster file)
   
# *InputRaster_MULTIPLE_INPUT_MimeType: Mime Types List separted from ',' for the multiple "InputRaster" Complex Data. 
#      (Each value correspond at the Mime Type of the file, called like the list position of the Mime Type value, in the "InputRaster_MULTIPLE_INPUT_FOLDER" folder)
#      (Supported:  image/tiff  application/x-netcdf3  application/x-netcdf4  application/x-hdf  )
    
# *Calculation: Local Path of Complex Value "Calculation" defined by reference in the Execute Request. 
#      (Input Description: Calculation in Content MathML format)
   
# *Calculation_MimeType: Mime Type of "Calculation" Input Complex Data. 
#      (Mime Type Supported:  text/xml  )
    
# *OutputDataType: Literal Datata "OutputDataType" Input value.
#      (Input Description: The data type of the raster output file)
#      (Allowed Values:  Byte  Int16  UInt16  UInt32  Int32  Float32  Float64  CInt16  CInt32  CFloat32  CFloat64  )
#					 
#					 
# ***************************************************************************************************************************************



# ********* Output Environment Variables *************************************************************************************************

# *OutputRaster: Name of the file that will contain the "OutputRaster" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
# *OutputRaster_OUTPUT_PATH: Path of the file that will contain the "OutputRaster" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputRaster")
#      (Output Description: Output raster file)
    
# *OutputRaster_MimeType: OutputRaster Output Mime Type (Mime type, for the OutputRaster Complex Output, required in the Execute Request).
#      (Mime Type Supported:  image/tiff  application/x-netcdf  application/x-hdf  image/png  image/jpeg  image/gif  )
    
#					 
#					 
#******************************************************************************************************************************


# ------------------------------  GRASS SCRIPT -------------------------------------------------------------------------------------------------------------------------------------



perl "$GENERAL_SERVICES_RESOURCES/scripts/rast_calc.pl" \
--unique_code="$INSTANCE_VALUE" \
--input_folder="$InputRaster_MULTIPLE_INPUT_FOLDER" \
--calculation="$Calculation" \
--output_file="$OUTPUT_REPOSITORY$OutputRaster" \
--output_mimetype="$OutputRaster_MimeType" \
--output_data_type="$OutputDataType"



# ------------------------------  END GRASS SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  

	
 # ------------------------------  OUTPUT MANAGER GRASS SCRIPT ------------------------------------------------------------------------------------------------------------------------------ 

     
     
              if [ -f "$OUTPUT_REPOSITORY$OutputRaster" ]; then 
                  echo "ComplexOutput "$OutputRaster" generated."
                  export ComplexOutputValueFile=$OUTPUT_REPOSITORY"OutputRaster.xml"
                  complexOutputControl="<?xml version=\"1.0\" encoding=\"UTF-8\"?><OutputGenerated>OK</OutputGenerated>"
                  echo $complexOutputControl >> $ComplexOutputValueFile
                  if [ "$RESPONSE_STORE" = "false"  -a "$OutputRaster_STORE" = "false" ]; then
                    export ComplexOutputValueFile=$OUTPUT_REPOSITORY"OutputRaster_Value.xml"
                    if [ "$OutputRaster_MimeType" != "text/xml" ]; then
                        complexOutputDocumentHeader="<?xml version=\"1.0\" encoding=\"UTF-8\"?><wps:Data xmlns:wps=\"http://www.opengis.net/wps/1.0.0\"><wps:ComplexData xmlns:ows=\"http://www.opengis.net/ows/1.1\">"
                        echo $complexOutputDocumentHeader >> $ComplexOutputValueFile
                        complexOutputDocumentFooter="</wps:ComplexData></wps:Data>"
                        if [ "$OutputRaster_GlobalType" = "BIN" ]; then
                              base64 $OUTPUT_REPOSITORY$OutputRaster >> $ComplexOutputValueFile
                          else
                              cat $OUTPUT_REPOSITORY$OutputRaster >> $ComplexOutputValueFile
                        fi
                        echo $complexOutputDocumentFooter >> $ComplexOutputValueFile
                      else
                       cat $OUTPUT_REPOSITORY$OutputRaster >> $ComplexOutputValueFile 
                    fi
                  fi
              else 
                  export ComplexOutputNULLFile=$OUTPUT_REPOSITORY"OutputRasterNULL.xml"
                  echo "Output "$OutputRaster" is NULL." >> $ComplexOutputNULLFile
                  echo "ComplexOutput "$OutputRaster" not generated."
              fi
              

            
# ------------------------------  END OUTPUT MANAGER GRASS SCRIPT ----------------------------------------------------------------------------------------------------------------------------
  
