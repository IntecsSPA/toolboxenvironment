
	
#############################################################################
#
# $Id: execute_RasterFormatConversion.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Convert a raster to another file format and stores the resulting raster file.
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory 
# *GENERAL_SERVICES_RESOURCES : General Services Resources Directory (This Folder contains all Toolbox services resources)
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains resources decicate service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)		
# *STATUS_FILE: File path for XML Status file		
		
#------Processing Variables	

# *InputRaster: Local Path of Complex Value "InputRaster" defined by reference in the Execute Request. 
#      (Input Description: Input raster file)
   
# *InputRaster_MimeType: Mime Type of "InputRaster" Input Complex Data. 
#      (Mime Type Supported:  image/tiff  application/x-netcdf3  application/x-netcdf4  application/x-hdf  )
    
# *InputRasterMetadata: Local Path of Complex Value "InputRasterMetadata" defined by reference in the Execute Request. 
#      (Input Description: Input raster metadata file)
   
# *InputRasterMetadata_MimeType: Mime Type of "InputRasterMetadata" Input Complex Data. 
#      (Mime Type Supported:  text/xml  )
    
# *Parameter_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "Parameter" Input.
#      (Input Description: The parameter (dataset) to extract from a netCDF file containing muliple datasets)
#      (Data Type: string)
# *SLD_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "SLD" Input.
#      (Input Description: 
#					If output = WMC, this parameter is required (otherwise it will be ignored).
#					If no parameters are provided, you'll have to provide exactly 1 SLD file.
#					If parameters are provided, the number of supplied SLD's should be equal to the number of parameters.
#				)
#      (Data Type: string)
# *GDALTranslateOptions: Literal Datata "GDALTranslateOptions" Input value.
#      (Input Description: Additional option(s) that will be passed to the gdal_translate command)
#      (Data Type: string)
# *LongitudeDataset: Literal Datata "LongitudeDataset" Input value.
#      (Input Description: 
#					The name of the NetCDF dataset containing the longitude.
#					If you provide the LongitudeDataset, you should also provide the LatitudeDataset.
#				)
#      (Data Type: string)
# *LatitudeDataset: Literal Datata "LatitudeDataset" Input value.
#      (Input Description: 
#					The name of the NetCDF dataset containing the latitude.
#					If you provide the LatitudeDataset, you should also provide the LongitudeDataset.
#				)
#      (Data Type: string)
# *Output_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "Output" Input.
#      (Input Description: The output of the process)
#      (Data Type: string)#      (Allowed Values:  file  WMC  )
# *OutputDataType: Literal Datata "OutputDataType" Input value.
#      (Input Description: The data type of the raster output file)
#      (Allowed Values:  Byte  Int16  UInt16  UInt32  Int32  Float32  Float64  CInt16  CInt32  CFloat32  CFloat64  )
# *OutputRaster: File Name of the "OutputRaster" Complex Data Output.
#      (Output Description: Output raster file)
    
# *OutputRaster_MimeType: OutputRaster Output Mime Type.
#      (Mime Type Supported:  image/tiff  application/x-netcdf  application/x-hdf  image/png  image/jpeg  image/gif  )
    
# *OutputRasterMetadata: File Name of the "OutputRasterMetadata" Complex Data Output.
#      (Output Description: Output raster file)
    
# *OutputRasterMetadata_MimeType: OutputRasterMetadata Output Mime Type.
#      (Mime Type Supported:  text/xml  )
    
# *OutputWMC: File Name of the "OutputWMC" Complex Data Output.
#      (Output Description: Web Map Context file containing references to Web Map Server instance)
    
# *OutputWMC_MimeType: OutputWMC Output Mime Type.
#      (Mime Type Supported:  text/xml  )
    

#					 
#******************************************************************************************************************************


# ------------------------------  SHELL SCRIPT -------------------------------------------------------------------------------------------------------------------------------------











                              # Add your shell statements here














# ------------------------------  END SHELL SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  
