
	
#############################################################################
#
# $Id: execute_VectorGeneralization.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Generalization or vector weeding is the process in which the complexity of vector data sets is reduced by reducing the number of vertices
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory 
# *GENERAL_SERVICES_RESOURCES : General Services Resources Directory (This Folder contains all Toolbox services resources)
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains resources decicate service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)		
# *STATUS_FILE: File path for XML Status file		
		
#------Processing Variables	

# *InputVector: Local Path of Complex Value "InputVector" defined by reference in the Execute Request. 
#      (Input Description: 
#					Input vector file
#					The input vector file should be zipped!
#				)
   
# *InputVector_MimeType: Mime Type of "InputVector" Input Complex Data. 
#      (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  image/vdn.dgn  text/csv  application/xml  application/vnd.google-earth.kml+xml  )
    
# *Method: Literal Datata "Method" Input value.
#      (Input Description: 
#					The generalization algorithm to use
#					   douglas: Douglas-Peucker Algorithm
#						douglas_reduction: Douglas-Peucker Algorithm with reduction parameter
#						lang: Lang Simplification Algorithm
#						reduction: Vertex Reduction Algorithm: removes the points of a line which are closer to each other than threshold
#						reumann: Reumann-Witkam Algorithm
#						remove_small: removes the lines (strictly) shorter than threshold and areas of area (strictly)less than threshold, other lines/areas/boundaries are left unchanged
#				)
#      (Allowed Values:  douglas  douglas_reduction  lang  reduction  reumann  remove_small  )
# *Threshold: Literal Datata "Threshold" Input value.
#      (Input Description: 
#						Maximal tolerance value
#						In general, the degree of simplification increases with the increasing value of threshold
#						Options: 0-1000000000
#						Default: 1.0
#    				)
#      (Data Type: float)#      (Allowed Values:  )
# *PercentageVerticesInOutput: Literal Datata "PercentageVerticesInOutput" Input value.
#      (Input Description: 
#					Percentage of the points in the output of 'douglas_reduction' algorithm
#					The default is 50
#					This parameter is ignored if the chosen method is not 'douglas_reduction'
#				)
#      (Data Type: positiveInteger)#      (Allowed Values:  )
# *LookAhead: Literal Datata "LookAhead" Input value.
#      (Input Description: 
#                  Look-ahead parameter used in the Lang Algorithm
#                  The default is 7
#                  This parameter is ignored if the chosen method is not 'lang'
#    				)
#      (Data Type: positiveInteger)#      (Allowed Values:  )
# *OutputType_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "OutputType" Input.
#      (Input Description: 
#					Feature types to export.
#					Note: A combination of types is not supported by all formats.
#					Default: line, boundary
#				)
#      (Allowed Values:  point  kernel  centroid  line  boundary  area  face  )
# *OutputVector: File Name of the "OutputVector" Complex Data Output.
#      (Output Description: A ZIP file will be returned, containing the vector file in the requested file format)
    
# *OutputVector_MimeType: OutputVector Output Mime Type.
#      (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  text/csv  application/xml  application/gpx+xml  application/vnd.google-earth.kml+xml  )
    

#					 
#******************************************************************************************************************************


# ------------------------------  SHELL SCRIPT -------------------------------------------------------------------------------------------------------------------------------------











                              # Add your shell statements here














# ------------------------------  END SHELL SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  
