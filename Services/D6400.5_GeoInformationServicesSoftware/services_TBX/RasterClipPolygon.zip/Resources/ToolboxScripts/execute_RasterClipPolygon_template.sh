
	


<!--                                                                 
 #############################################################################
 
  $Id: execute_RasterClipPolygon.sh,v    $
  UPDATED:	
 
  MODULE:   	TEST MODULE 
 
  AUTHOR(S):	Insert autors
                
  PURPOSE:  	Clips a raster (coverage file) to a polygon and stores the resulting raster
 
  COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
  
 #############################################################################-->
                
                                                                              

<!--
  ********* External TOOLBOX Variables ************************************************************************************************
  -----WPS Service Varibles
  *OUTPUT_REPOSITORY : Output Repository Directory (This Folder should contain all the GRASS output files)
  *GENERAL_SERVICES_RESOURCES : Services General Resources Directory (This Folder contains general resources for all Toolbox services ).
  *SERVICE_RESOURCES : Service Resources Directory (This Folder contains only the resources of the current service)
  *TEMP_REPOSITORY : Temporaney Data created Repository Directory (This Folder should contain all the temporaney files)		
  *WPS_PROCESSING_NAME: WPS Processing Name
  *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)
  *GRASS_LOG_FILE: File path for GRASS text LOG	(This File should contain all GRASS messages)
  *STATUS_FILE: File path for XML Status file (This XML File should contain the status information of the GRASS operation)		
 					 
 					 
  ***************************************************************************************************************************************-->
		
<!--		
  ********* Input TOOLBOX Variables ***************************************************************************************************

  *InputRaster: Local Path of Complex Value "InputRaster" defined by reference in the Execute Request. 
       (Input Description: Input raster file)
   
  *InputRaster_MimeType: Mime Type of "InputRaster" Input Complex Data. 
       (Mime Type Supported:  image/tiff  application/x-netcdf3  application/x-netcdf4  application/x-hdf  )
    
  *InputPolygon: Local Path of Complex Value "InputPolygon" defined by reference in the Execute Request. 
       (Input Description: 
 					The input polygon
 					If the input polygon is a shapefile, this shapefile should be zipped
 				)
   
  *InputPolygon_MimeType: Mime Type of "InputPolygon" Input Complex Data. 
       (Mime Type Supported:  application/x-esri-shapefile  application/xml  )
    
  *CRS: Literal Datata "CRS" Input value.
       (Input Description: The CRS of the output raster file (the original CRS of the raster file will be overridden))
       (Data Type: string)
 					 
 					 
  ***************************************************************************************************************************************-->


<!--
  ********* Output TOOLBOX Variables *************************************************************************************************

  *OutputRaster: Name of the file that will contain the "OutputRaster" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
  *OutputRaster_OUTPUT_PATH: Path of the file that will contain the "OutputRaster" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputRaster")
       (Output Description: Output raster file)
    
  *OutputRaster_MimeType: OutputRaster Output Mime Type (Mime type, for the OutputRaster Complex Output, required in the Execute Request).
       (Mime Type Supported:  image/tiff  application/x-netcdf  application/x-hdf  image/png  image/jpeg  image/gif  )
    
 					 
 					 
 ******************************************************************************************************************************-->


<!--  ------------------------------  TOOLBOX SCRIPT --------------------------------------------------------------------------------------------------------------------------------------->











                             <!--  Insert TOOLBOX Script-->














<!-- ------------------------------  END TOOLBOX SCRIPT -------------------------------------------------------------------------------------------------------------------------------->
  
