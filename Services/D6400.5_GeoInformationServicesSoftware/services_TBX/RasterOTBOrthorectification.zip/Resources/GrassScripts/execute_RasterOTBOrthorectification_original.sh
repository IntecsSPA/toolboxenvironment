
	
#!/bin/bash

#############################################################################
#
# $Id: execute_RasterOTBOrthorectification.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Orthorectificates a raster
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Environment Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory (This Folder should contain all the GRASS output files)
# *GENERAL_SERVICES_RESOURCES : Services General Resources Directory (This Folder contains general resources for all Toolbox services ).
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains only the resources of the current service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory (This Folder should contain all the temporaney files)		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)
# *GRASS_LOG_FILE: File path for GRASS text LOG	(This File should contain all GRASS messages)
# *STATUS_FILE: File path for XML Status file (This XML File should contain the status information of the GRASS operation)		
#					 
#					 
# ***************************************************************************************************************************************
		
		
# ********* Input Environment Variables ***************************************************************************************************

# *InputRaster: Local Path of Complex Value "InputRaster" defined by reference in the Execute Request. 
#      (Input Description: Input raster file)
   
# *InputRaster_MimeType: Mime Type of "InputRaster" Input Complex Data. 
#      (Mime Type Supported:  image/tiff  )
    
# *UTMZone: Literal Datata "UTMZone" Input value.
#      (Input Description: The UTM zone)
#      (Data Type: string)
# *UTMHemisphere: Literal Datata "UTMHemisphere" Input value.
#      (Input Description: The UTM Hemisphere)
#      (Allowed Values:  N  S  )
# *UpperLeftX: Literal Datata "UpperLeftX" Input value.
#      (Input Description: X coordinate of upper left pixel)
#      (Data Type: integer)
# *UpperLeftY: Literal Datata "UpperLeftY" Input value.
#      (Input Description: Y coordinate of upper left pixel)
#      (Data Type: integer)
# *NumberOfRows: Literal Datata "NumberOfRows" Input value.
#      (Input Description: The number of rows)
#      (Data Type: integer)
# *NumberOfColumns: Literal Datata "NumberOfColumns" Input value.
#      (Input Description: The number of columns)
#      (Data Type: integer)
# *ResolutionX: Literal Datata "ResolutionX" Input value.
#      (Input Description: The resolution in X direction)
#      (Data Type: float)
# *ResolutionY: Literal Datata "ResolutionY" Input value.
#      (Input Description: The resolution in Y direction. Note: this should be a negative number!)
#      (Data Type: float)
#					 
#					 
# ***************************************************************************************************************************************



# ********* Output Environment Variables *************************************************************************************************

# *OutputRaster: Name of the file that will contain the "OutputRaster" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
# *OutputRaster_OUTPUT_PATH: Path of the file that will contain the "OutputRaster" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputRaster")
#      (Output Description: Output raster file)
    
# *OutputRaster_MimeType: OutputRaster Output Mime Type (Mime type, for the OutputRaster Complex Output, required in the Execute Request).
#      (Mime Type Supported:  image/tiff  application/x-netcdf  application/x-hdf  image/png  image/jpeg  image/gif  )
    
#					 
#					 
#******************************************************************************************************************************


# ------------------------------  GRASS SCRIPT -------------------------------------------------------------------------------------------------------------------------------------


perl "$GENERAL_SERVICES_RESOURCES/scripts/rast_otb_orthorectification.pl" \
--unique_code="$INSTANCE_VALUE" \
--input_raster="$InputRaster" \
--utm_zone="$UTMZone" \
--utm_hemisphere="$UTMHemisphere" \
--upper_left_x="$UpperLeftX" \
--upper_left_y="$UpperLeftY" \
--number_rows="$NumberOfRows" \
--number_columns="$NumberOfColumns" \
--resolution_x="$ResolutionX" \
--resolution_y="$ResolutionY" \
--output_raster="$OutputRaster_OUTPUT_PATH" \
--output_raster_mimetype="$OutputRaster_MimeType"


# ------------------------------  END GRASS SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  
