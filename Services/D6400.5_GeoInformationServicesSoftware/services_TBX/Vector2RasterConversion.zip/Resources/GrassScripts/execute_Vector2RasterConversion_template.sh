
	
#!/bin/bash

#############################################################################
#
# $Id: execute_Vector2RasterConversion.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Converts a vector to a raster data set
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Environment Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory (This Folder should contain all the GRASS output files)
# *GENERAL_SERVICES_RESOURCES : Services General Resources Directory (This Folder contains general resources for all Toolbox services ).
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains only the resources of the current service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory (This Folder should contain all the temporaney files)		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)
# *GRASS_LOG_FILE: File path for GRASS text LOG	(This File should contain all GRASS messages)
# *STATUS_FILE: File path for XML Status file (This XML File should contain the status information of the GRASS operation)		
#					 
#					 
# ***************************************************************************************************************************************
		
		
# ********* Input Environment Variables ***************************************************************************************************

# *InputVector: Local Path of Complex Value "InputVector" defined by reference in the Execute Request. 
#      (Input Description: 
#					Input vector file.
#					The input vector file should be zipped!
#				)
   
# *InputVector_MimeType: Mime Type of "InputVector" Input Complex Data. 
#      (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  image/vdn.dgn  text/csv  application/xml  application/vnd.google-earth.kml+xml  )
    
# *SourceAttribute: Literal Datata "SourceAttribute" Input value.
#      (Input Description: 
#					The attribute (property) in the vector data that shall be converted
#					The type of this attribute has to be numeric
#				)
#      (Data Type: string)
# *Resolution: Literal Datata "Resolution" Input value.
#      (Input Description: The resolution to resample to (in target georeferenced units and in both directions))
#      (Data Type: float)
# *FeatureType_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "FeatureType" Input.
#      (Input Description: 
#					Feature types to export.
#					Default: point, line, area
#				)
#      (Allowed Values:  point  line  area  )
# *OutputDataType: Literal Datata "OutputDataType" Input value.
#      (Input Description: The data type of the raster output file)
#      (Allowed Values:  Byte  Int16  UInt16  UInt32  Int32  Float32  Float64  CInt16  CInt32  CFloat32  CFloat64  )
#					 
#					 
# ***************************************************************************************************************************************



# ********* Output Environment Variables *************************************************************************************************

# *OutputRaster: Name of the file that will contain the "OutputRaster" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
# *OutputRaster_OUTPUT_PATH: Path of the file that will contain the "OutputRaster" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputRaster")
#      (Output Description: Output raster file)
    
# *OutputRaster_MimeType: OutputRaster Output Mime Type (Mime type, for the OutputRaster Complex Output, required in the Execute Request).
#      (Mime Type Supported:  image/tiff  application/x-netcdf  application/x-hdf  image/png  image/jpeg  image/gif  )
    
#					 
#					 
#******************************************************************************************************************************


# ------------------------------  GRASS SCRIPT -------------------------------------------------------------------------------------------------------------------------------------











                              # Insert GRASS Script














# ------------------------------  END GRASS SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  
