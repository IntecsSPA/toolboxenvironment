
	
#############################################################################
#
# $Id: execute_Vector2RasterConversion.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Converts a vector to a raster data set
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory 
# *GENERAL_SERVICES_RESOURCES : General Services Resources Directory (This Folder contains all Toolbox services resources)
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains resources decicate service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)		
# *STATUS_FILE: File path for XML Status file		
		
#------Processing Variables	

# *InputVector: Local Path of Complex Value "InputVector" defined by reference in the Execute Request. 
#      (Input Description: 
#					Input vector file.
#					The input vector file should be zipped!
#				)
   
# *InputVector_MimeType: Mime Type of "InputVector" Input Complex Data. 
#      (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  image/vdn.dgn  text/csv  application/xml  application/vnd.google-earth.kml+xml  )
    
# *SourceAttribute: Literal Datata "SourceAttribute" Input value.
#      (Input Description: 
#					The attribute (property) in the vector data that shall be converted
#					The type of this attribute has to be numeric
#				)
#      (Data Type: string)
# *Resolution: Literal Datata "Resolution" Input value.
#      (Input Description: The resolution to resample to (in target georeferenced units and in both directions))
#      (Data Type: float)
# *FeatureType_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "FeatureType" Input.
#      (Input Description: 
#					Feature types to export.
#					Default: point, line, area
#				)
#      (Allowed Values:  point  line  area  )
# *OutputDataType: Literal Datata "OutputDataType" Input value.
#      (Input Description: The data type of the raster output file)
#      (Allowed Values:  Byte  Int16  UInt16  UInt32  Int32  Float32  Float64  CInt16  CInt32  CFloat32  CFloat64  )
# *OutputRaster: File Name of the "OutputRaster" Complex Data Output.
#      (Output Description: Output raster file)
    
# *OutputRaster_MimeType: OutputRaster Output Mime Type.
#      (Mime Type Supported:  image/tiff  application/x-netcdf  application/x-hdf  image/png  image/jpeg  image/gif  )
    

#					 
#******************************************************************************************************************************


# ------------------------------  SHELL SCRIPT -------------------------------------------------------------------------------------------------------------------------------------











                              # Add your shell statements here














# ------------------------------  END SHELL SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  
