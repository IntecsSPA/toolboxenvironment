
	
#!/bin/bash

#############################################################################
#
# $Id: execute_VectorClipPolygon.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Clips a vector to a polygon stores the resulting vector file.
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Environment Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory (This Folder should contain all the GRASS output files)
# *GENERAL_SERVICES_RESOURCES : Services General Resources Directory (This Folder contains general resources for all Toolbox services ).
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains only the resources of the current service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory (This Folder should contain all the temporaney files)		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)
# *GRASS_LOG_FILE: File path for GRASS text LOG	(This File should contain all GRASS messages)
# *STATUS_FILE: File path for XML Status file (This XML File should contain the status information of the GRASS operation)		
#					 
#					 
# ***************************************************************************************************************************************
		
		
# ********* Input Environment Variables ***************************************************************************************************

# *InputVector: Local Path of Complex Value "InputVector" defined by reference in the Execute Request. 
#      (Input Description: 
#					Input vector file
#					The input vector file should be zipped!
#				)
   
# *InputVector_MimeType: Mime Type of "InputVector" Input Complex Data. 
#      (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  image/vdn.dgn  text/csv  application/xml  application/vnd.google-earth.kml+xml  )
    
# *InputPolygon: Local Path of Complex Value "InputPolygon" defined by reference in the Execute Request. 
#      (Input Description: Input polygon)
   
# *InputPolygon_MimeType: Mime Type of "InputPolygon" Input Complex Data. 
#      (Mime Type Supported:  application/xml  )
    
# *OutputType_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "OutputType" Input.
#      (Input Description: 
#					Feature types to export.
#					Note: A combination of types is not supported by all formats.
#					Default: line, boundary
#				)
#      (Allowed Values:  point  kernel  centroid  line  boundary  area  face  )
#					 
#					 
# ***************************************************************************************************************************************



# ********* Output Environment Variables *************************************************************************************************

# *OutputVector: Name of the file that will contain the "OutputVector" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
# *OutputVector_OUTPUT_PATH: Path of the file that will contain the "OutputVector" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputVector")
#      (Output Description: A ZIP file will be returned, containing the vector file in the requested file format)
    
# *OutputVector_MimeType: OutputVector Output Mime Type (Mime type, for the OutputVector Complex Output, required in the Execute Request).
#      (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  text/csv  application/xml  application/gpx+xml  application/vnd.google-earth.kml+xml  )
    
#					 
#					 
#******************************************************************************************************************************


# ------------------------------  GRASS SCRIPT -------------------------------------------------------------------------------------------------------------------------------------


perl "$GENERAL_SERVICES_RESOURCES/scripts/vect_clip_polygon.pl" \
--unique_code="$INSTANCE_VALUE" \
--input_file="$InputVector" \
--input_mimetype="$InputVector_MimeType" \
--input_polygon="$InputPolygon" \
--output_file="$OUTPUT_REPOSITORY$OutputVector" \
--output_mimetype="$OutputVector_MimeType" \
--output_types="$OutputType_MULTIPLE_LITERAL_LIST"


# ------------------------------  END GRASS SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  
