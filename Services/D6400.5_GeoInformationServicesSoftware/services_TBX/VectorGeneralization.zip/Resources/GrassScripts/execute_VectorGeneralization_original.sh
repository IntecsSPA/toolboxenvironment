
	
#!/bin/bash

#############################################################################
#
# $Id: execute_VectorGeneralization.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Generalization or vector weeding is the process in which the complexity of vector data sets is reduced by reducing the number of vertices
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Environment Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory (This Folder should contain all the GRASS output files)
# *GENERAL_SERVICES_RESOURCES : Services General Resources Directory (This Folder contains general resources for all Toolbox services ).
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains only the resources of the current service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory (This Folder should contain all the temporaney files)		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)
# *GRASS_LOG_FILE: File path for GRASS text LOG	(This File should contain all GRASS messages)
# *STATUS_FILE: File path for XML Status file (This XML File should contain the status information of the GRASS operation)		
#					 
#					 
# ***************************************************************************************************************************************
		
		
# ********* Input Environment Variables ***************************************************************************************************

# *InputVector: Local Path of Complex Value "InputVector" defined by reference in the Execute Request. 
#      (Input Description: 
#					Input vector file
#					The input vector file should be zipped!
#				)
   
# *InputVector_MimeType: Mime Type of "InputVector" Input Complex Data. 
#      (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  image/vdn.dgn  text/csv  application/xml  application/vnd.google-earth.kml+xml  )
    
# *Method: Literal Datata "Method" Input value.
#      (Input Description: 
#					The generalization algorithm to use
#					   douglas: Douglas-Peucker Algorithm
#						douglas_reduction: Douglas-Peucker Algorithm with reduction parameter
#						lang: Lang Simplification Algorithm
#						reduction: Vertex Reduction Algorithm: removes the points of a line which are closer to each other than threshold
#						reumann: Reumann-Witkam Algorithm
#						remove_small: removes the lines (strictly) shorter than threshold and areas of area (strictly)less than threshold, other lines/areas/boundaries are left unchanged
#				)
#      (Allowed Values:  douglas  douglas_reduction  lang  reduction  reumann  remove_small  )
# *Threshold: Literal Datata "Threshold" Input value.
#      (Input Description: 
#						Maximal tolerance value
#						In general, the degree of simplification increases with the increasing value of threshold
#						Options: 0-1000000000
#						Default: 1.0
#    				)
#      (Data Type: float)#      (Allowed Values:  )
# *PercentageVerticesInOutput: Literal Datata "PercentageVerticesInOutput" Input value.
#      (Input Description: 
#					Percentage of the points in the output of 'douglas_reduction' algorithm
#					The default is 50
#					This parameter is ignored if the chosen method is not 'douglas_reduction'
#				)
#      (Data Type: positiveInteger)#      (Allowed Values:  )
# *LookAhead: Literal Datata "LookAhead" Input value.
#      (Input Description: 
#                  Look-ahead parameter used in the Lang Algorithm
#                  The default is 7
#                  This parameter is ignored if the chosen method is not 'lang'
#    				)
#      (Data Type: positiveInteger)#      (Allowed Values:  )
# *OutputType_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "OutputType" Input.
#      (Input Description: 
#					Feature types to export.
#					Note: A combination of types is not supported by all formats.
#					Default: line, boundary
#				)
#      (Allowed Values:  point  kernel  centroid  line  boundary  area  face  )
#					 
#					 
# ***************************************************************************************************************************************



# ********* Output Environment Variables *************************************************************************************************

# *OutputVector: Name of the file that will contain the "OutputVector" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
# *OutputVector_OUTPUT_PATH: Path of the file that will contain the "OutputVector" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputVector")
#      (Output Description: A ZIP file will be returned, containing the vector file in the requested file format)
    
# *OutputVector_MimeType: OutputVector Output Mime Type (Mime type, for the OutputVector Complex Output, required in the Execute Request).
#      (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  text/csv  application/xml  application/gpx+xml  application/vnd.google-earth.kml+xml  )
    
#					 
#					 
#******************************************************************************************************************************


# ------------------------------  GRASS SCRIPT -------------------------------------------------------------------------------------------------------------------------------------


perl "$GENERAL_SERVICES_RESOURCES/scripts/vect_generalization.pl" \
--unique_code="$INSTANCE_VALUE" \
--input_file="$InputVector" \
--input_mimetype="$InputVector_MimeType" \
--method="$Method" \
--threshold="$Threshold" \
--percentage_vertices_output="$PercentageVerticesInOutput" \
--look_ahead="$LookAhead" \
--output_file="$OUTPUT_REPOSITORY$OutputVector" \
--output_mimetype="$OutputVector_MimeType" \
--output_types="$OutputType_MULTIPLE_LITERAL_LIST"



# ------------------------------  END GRASS SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  
