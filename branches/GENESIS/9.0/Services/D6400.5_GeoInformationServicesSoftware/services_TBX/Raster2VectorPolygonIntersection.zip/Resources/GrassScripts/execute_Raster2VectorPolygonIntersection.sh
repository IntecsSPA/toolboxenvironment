
	
#!/bin/bash

#############################################################################
#
# $Id: execute_Raster2VectorPolygonIntersection.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Performs a spatial overlay of a raster file with a vector polygon file, calculates the min,max, avg, median or stdev of the pixel values within the polygons and assign the calculated values to the polygons.
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Environment Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory (This Folder should contain all the GRASS output files)
# *GENERAL_SERVICES_RESOURCES : Services General Resources Directory (This Folder contains general resources for all Toolbox services ).
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains only the resources of the current service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory (This Folder should contain all the temporaney files)		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)
# *GRASS_LOG_FILE: File path for GRASS text LOG	(This File should contain all GRASS messages)
# *STATUS_FILE: File path for XML Status file (This XML File should contain the status information of the GRASS operation)		
#					 
#					 
# ***************************************************************************************************************************************
		
		
# ********* Input Environment Variables ***************************************************************************************************

# *InputRaster: Local Path of Complex Value "InputRaster" defined by reference in the Execute Request. 
#      (Input Description: The input raster file)
   
# *InputRaster_MimeType: Mime Type of "InputRaster" Input Complex Data. 
#      (Mime Type Supported:  image/tiff  application/x-netcdf3  application/x-netcdf4  application/x-hdf  )
    
# *VectorOverlay: Local Path of Complex Value "VectorOverlay" defined by reference in the Execute Request. 
#      (Input Description: 
#					The input vector file used as an overlay for the raster.
#					This should be a zip file containing the shapefiles.
#				)
   
# *VectorOverlay_MimeType: Mime Type of "VectorOverlay" Input Complex Data. 
#      (Mime Type Supported:  application/x-esri-shape  )
    
# *Output_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "Output" Input.
#      (Input Description: The output of the process)
#      (Data Type: string)#      (Allowed Values:  CSV  shape  WMC  )
# *PolygonIDProperty: Literal Datata "PolygonIDProperty" Input value.
#      (Input Description: 
#					The property containing the ID of the polygon in the shapefile
#					This parameter is required if output=WMC and is ignored if output is any other value.
#				)
#      (Data Type: string)
# *Elevation: Literal Datata "Elevation" Input value.
#      (Input Description: 
#					The elevation of the measurements (in meters) in the input raster.
#					This parameter is required if output=WMC and is ignored if output is any other value.
#				)
#      (Data Type: integer)
# *Elevation_UOM: Unit of Measure of "Elevation" Literal Data. 
#      (Supported:  meters  )

    
# *Parameter: Literal Datata "Parameter" Input value.
#      (Input Description: 
#					The measured property in the input raster.
#					This parameter is required if output=WMC and is ignored if output is any other value.
#				)
#      (Data Type: string)#      (Allowed Values:  no2  )
# *Timestamps: Literal Datata "Timestamps" Input value.
#      (Input Description: 
#					The times when the measurements in the bands of the input raster were performed.
#					The timestamps should be seperated by a comma .
#					The first timestamp represents the time of measurement of the first band in the input raster,
#					the second timestamp  represents the time of measurement of the second band, and so on.
#					This parameter is required if output=WMC and is ignored if output is any other value.
#				)
#      (Data Type: dateTime)
#					 
#					 
# ***************************************************************************************************************************************



# ********* Output Environment Variables *************************************************************************************************

# *OutputVectorShape: Name of the file that will contain the "OutputVectorShape" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
# *OutputVectorShape_OUTPUT_PATH: Path of the file that will contain the "OutputVectorShape" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputVectorShape")
#      (Output Description: The zipped output vector shapefile)
    
# *OutputVectorShape_MimeType: OutputVectorShape Output Mime Type (Mime type, for the OutputVectorShape Complex Output, required in the Execute Request).
#      (Mime Type Supported:  application/x-esri-shape  )
    
# *OutputVectorCSV: Name of the file that will contain the "OutputVectorCSV" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
# *OutputVectorCSV_OUTPUT_PATH: Path of the file that will contain the "OutputVectorCSV" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputVectorCSV")
#      (Output Description: The output vector file in CSV format)
    
# *OutputVectorCSV_MimeType: OutputVectorCSV Output Mime Type (Mime type, for the OutputVectorCSV Complex Output, required in the Execute Request).
#      (Mime Type Supported:  text/csv  )
    
# *OutputWMC: Name of the file that will contain the "OutputWMC" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
# *OutputWMC_OUTPUT_PATH: Path of the file that will contain the "OutputWMC" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputWMC")
#      (Output Description: WebMapContext file containing WMS and SOS)
    
# *OutputWMC_MimeType: OutputWMC Output Mime Type (Mime type, for the OutputWMC Complex Output, required in the Execute Request).
#      (Mime Type Supported:  text/xml  )
    
#					 
#					 
#******************************************************************************************************************************


# ------------------------------  GRASS SCRIPT -------------------------------------------------------------------------------------------------------------------------------------



perl "$GENERAL_SERVICES_RESOURCES/scripts/rast_vect_polygon_intersection.pl" \
--unique_code="$INSTANCE_VALUE" \
--input_raster_file="$InputRaster" \
--input_vector_file="$VectorOverlay" \
--output="$Output_MULTIPLE_LITERAL_LIST" \
--polygon_ID_property="$PolygonIDProperty" \
--elevation="$Elevation" \
--parameter="$Parameter" \
--timestamps="$Timestamps" \
--output_shape="$OUTPUT_REPOSITORY$OutputVectorShape" \
--output_csv="$OUTPUT_REPOSITORY$OutputVectorCSV" \
--output_wmc="${OUTPUT_REPOSITORY}$OutputWMC"



# ------------------------------  END GRASS SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  

	
 # ------------------------------  OUTPUT MANAGER GRASS SCRIPT ------------------------------------------------------------------------------------------------------------------------------ 

     
     
              if [ -f "$OUTPUT_REPOSITORY$OutputVectorShape" ]; then 
                  echo "ComplexOutput "$OutputVectorShape" generated."
                  export ComplexOutputValueFile=$OUTPUT_REPOSITORY"OutputVectorShape.xml"
                  complexOutputControl="<?xml version=\"1.0\" encoding=\"UTF-8\"?><OutputGenerated>OK</OutputGenerated>"
                  echo $complexOutputControl >> $ComplexOutputValueFile
                  if [ "$RESPONSE_STORE" = "false"  -a "$OutputVectorShape_STORE" = "false" ]; then
                    export ComplexOutputValueFile=$OUTPUT_REPOSITORY"OutputVectorShape_Value.xml"
                    if [ "$OutputVectorShape_MimeType" != "text/xml" ]; then
                        complexOutputDocumentHeader="<?xml version=\"1.0\" encoding=\"UTF-8\"?><wps:Data xmlns:wps=\"http://www.opengis.net/wps/1.0.0\"><wps:ComplexData xmlns:ows=\"http://www.opengis.net/ows/1.1\">"
                        echo $complexOutputDocumentHeader >> $ComplexOutputValueFile
                        complexOutputDocumentFooter="</wps:ComplexData></wps:Data>"
                        if [ "$OutputVectorShape_GlobalType" = "BIN" ]; then
                              base64 $OUTPUT_REPOSITORY$OutputVectorShape >> $ComplexOutputValueFile
                          else
                              cat $OutputVectorShape >> $ComplexOutputValueFile
                        fi
                        echo $complexOutputDocumentFooter >> $ComplexOutputValueFile
                      else
                       cat $OUTPUT_REPOSITORY$OutputVectorShape >> $ComplexOutputValueFile 
                    fi
                  fi
              else 
                  export ComplexOutputNULLFile=$OUTPUT_REPOSITORY"OutputVectorShapeNULL.xml"
                  echo "Output "$OutputVectorShape" is NULL." >> $ComplexOutputNULLFile
                  echo "ComplexOutput "$OutputVectorShape" not generated."
              fi
              

            
              if [ -f "$OUTPUT_REPOSITORY$OutputVectorCSV" ]; then 
                  echo "ComplexOutput "$OutputVectorCSV" generated."
                  export ComplexOutputValueFile=$OUTPUT_REPOSITORY"OutputVectorCSV.xml"
                  complexOutputControl="<?xml version=\"1.0\" encoding=\"UTF-8\"?><OutputGenerated>OK</OutputGenerated>"
                  echo $complexOutputControl >> $ComplexOutputValueFile
                  if [ "$RESPONSE_STORE" = "false"  -a "$OutputVectorCSV_STORE" = "false" ]; then
                    export ComplexOutputValueFile=$OUTPUT_REPOSITORY"OutputVectorCSV_Value.xml"
                    if [ "$OutputVectorCSV_MimeType" != "text/xml" ]; then
                        complexOutputDocumentHeader="<?xml version=\"1.0\" encoding=\"UTF-8\"?><wps:Data xmlns:wps=\"http://www.opengis.net/wps/1.0.0\"><wps:ComplexData xmlns:ows=\"http://www.opengis.net/ows/1.1\">"
                        echo $complexOutputDocumentHeader >> $ComplexOutputValueFile
                        complexOutputDocumentFooter="</wps:ComplexData></wps:Data>"
                        if [ "$OutputVectorCSV_GlobalType" = "BIN" ]; then
                              base64 $OUTPUT_REPOSITORY$OutputVectorCSV >> $ComplexOutputValueFile
                          else
                              cat $OutputVectorCSV >> $ComplexOutputValueFile
                        fi
                        echo $complexOutputDocumentFooter >> $ComplexOutputValueFile
                      else
                       cat $OUTPUT_REPOSITORY$OutputVectorCSV >> $ComplexOutputValueFile 
                    fi
                  fi
              else 
                  export ComplexOutputNULLFile=$OUTPUT_REPOSITORY"OutputVectorCSVNULL.xml"
                  echo "Output "$OutputVectorCSV" is NULL." >> $ComplexOutputNULLFile
                  echo "ComplexOutput "$OutputVectorCSV" not generated."
              fi
              

            
              if [ -f "$OUTPUT_REPOSITORY$OutputWMC" ]; then 
                  echo "ComplexOutput "$OutputWMC" generated."
                  export ComplexOutputValueFile=$OUTPUT_REPOSITORY"OutputWMC.xml"
                  complexOutputControl="<?xml version=\"1.0\" encoding=\"UTF-8\"?><OutputGenerated>OK</OutputGenerated>"
                  echo $complexOutputControl >> $ComplexOutputValueFile
                  if [ "$RESPONSE_STORE" = "false"  -a "$OutputWMC_STORE" = "false" ]; then
                    export ComplexOutputValueFile=$OUTPUT_REPOSITORY"OutputWMC_Value.xml"
                    if [ "$OutputWMC_MimeType" != "text/xml" ]; then
                        complexOutputDocumentHeader="<?xml version=\"1.0\" encoding=\"UTF-8\"?><wps:Data xmlns:wps=\"http://www.opengis.net/wps/1.0.0\"><wps:ComplexData xmlns:ows=\"http://www.opengis.net/ows/1.1\">"
                        echo $complexOutputDocumentHeader >> $ComplexOutputValueFile
                        complexOutputDocumentFooter="</wps:ComplexData></wps:Data>"
                        if [ "$OutputWMC_GlobalType" = "BIN" ]; then
                              base64 $OUTPUT_REPOSITORY$OutputWMC >> $ComplexOutputValueFile
                          else
                              cat $OutputWMC >> $ComplexOutputValueFile
                        fi
                        echo $complexOutputDocumentFooter >> $ComplexOutputValueFile
                      else
                       cat $OUTPUT_REPOSITORY$OutputWMC >> $ComplexOutputValueFile 
                    fi
                  fi
              else 
                  export ComplexOutputNULLFile=$OUTPUT_REPOSITORY"OutputWMCNULL.xml"
                  echo "Output "$OutputWMC" is NULL." >> $ComplexOutputNULLFile
                  echo "ComplexOutput "$OutputWMC" not generated."
              fi
              

            
# ------------------------------  END OUTPUT MANAGER GRASS SCRIPT ----------------------------------------------------------------------------------------------------------------------------
  
