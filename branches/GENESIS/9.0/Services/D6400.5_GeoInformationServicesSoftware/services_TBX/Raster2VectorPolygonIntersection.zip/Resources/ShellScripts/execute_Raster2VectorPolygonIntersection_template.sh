
	
#############################################################################
#
# $Id: execute_Raster2VectorPolygonIntersection.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Performs a spatial overlay of a raster file with a vector polygon file, calculates the min,max, avg, median or stdev of the pixel values within the polygons and assign the calculated values to the polygons.
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory 
# *GENERAL_SERVICES_RESOURCES : General Services Resources Directory (This Folder contains all Toolbox services resources)
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains resources decicate service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)		
# *STATUS_FILE: File path for XML Status file		
		
#------Processing Variables	

# *InputRaster: Local Path of Complex Value "InputRaster" defined by reference in the Execute Request. 
#      (Input Description: The input raster file)
   
# *InputRaster_MimeType: Mime Type of "InputRaster" Input Complex Data. 
#      (Mime Type Supported:  image/tiff  application/x-netcdf3  application/x-netcdf4  application/x-hdf  )
    
# *VectorOverlay: Local Path of Complex Value "VectorOverlay" defined by reference in the Execute Request. 
#      (Input Description: 
#					The input vector file used as an overlay for the raster.
#					This should be a zip file containing the shapefiles.
#				)
   
# *VectorOverlay_MimeType: Mime Type of "VectorOverlay" Input Complex Data. 
#      (Mime Type Supported:  application/x-esri-shape  )
    
# *Output_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "Output" Input.
#      (Input Description: The output of the process)
#      (Data Type: string)#      (Allowed Values:  CSV  shape  WMC  )
# *PolygonIDProperty: Literal Datata "PolygonIDProperty" Input value.
#      (Input Description: 
#					The property containing the ID of the polygon in the shapefile
#					This parameter is required if output=WMC and is ignored if output is any other value.
#				)
#      (Data Type: string)
# *Elevation: Literal Datata "Elevation" Input value.
#      (Input Description: 
#					The elevation of the measurements (in meters) in the input raster.
#					This parameter is required if output=WMC and is ignored if output is any other value.
#				)
#      (Data Type: integer)
# *Elevation_UOM: Unit of Measure of "Elevation" Literal Data. 
#      (Supported:  meters  )

    
# *Parameter: Literal Datata "Parameter" Input value.
#      (Input Description: 
#					The measured property in the input raster.
#					This parameter is required if output=WMC and is ignored if output is any other value.
#				)
#      (Data Type: string)#      (Allowed Values:  no2  )
# *Timestamps: Literal Datata "Timestamps" Input value.
#      (Input Description: 
#					The times when the measurements in the bands of the input raster were performed.
#					The timestamps should be seperated by a comma .
#					The first timestamp represents the time of measurement of the first band in the input raster,
#					the second timestamp  represents the time of measurement of the second band, and so on.
#					This parameter is required if output=WMC and is ignored if output is any other value.
#				)
#      (Data Type: dateTime)
# *OutputVectorShape: File Name of the "OutputVectorShape" Complex Data Output.
#      (Output Description: The zipped output vector shapefile)
    
# *OutputVectorShape_MimeType: OutputVectorShape Output Mime Type.
#      (Mime Type Supported:  application/x-esri-shape  )
    
# *OutputVectorCSV: File Name of the "OutputVectorCSV" Complex Data Output.
#      (Output Description: The output vector file in CSV format)
    
# *OutputVectorCSV_MimeType: OutputVectorCSV Output Mime Type.
#      (Mime Type Supported:  text/csv  )
    
# *OutputWMC: File Name of the "OutputWMC" Complex Data Output.
#      (Output Description: WebMapContext file containing WMS and SOS)
    
# *OutputWMC_MimeType: OutputWMC Output Mime Type.
#      (Mime Type Supported:  text/xml  )
    

#					 
#******************************************************************************************************************************


# ------------------------------  SHELL SCRIPT -------------------------------------------------------------------------------------------------------------------------------------











                              # Add your shell statements here














# ------------------------------  END SHELL SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  
