
	


<!--                                                                 
 #############################################################################
 
  $Id: execute_Raster2VectorPolylinesIntersection.sh,v    $
  UPDATED:	
 
  MODULE:   	TEST MODULE 
 
  AUTHOR(S):	Insert autors
                
  PURPOSE:  	Creates a vector map based on the intersection of a raster with a given set of polylines
 
  COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
  
 #############################################################################-->
                
                                                                              

<!--
  ********* External TOOLBOX Variables ************************************************************************************************
  -----WPS Service Varibles
  *OUTPUT_REPOSITORY : Output Repository Directory (This Folder should contain all the GRASS output files)
  *GENERAL_SERVICES_RESOURCES : Services General Resources Directory (This Folder contains general resources for all Toolbox services ).
  *SERVICE_RESOURCES : Service Resources Directory (This Folder contains only the resources of the current service)
  *TEMP_REPOSITORY : Temporaney Data created Repository Directory (This Folder should contain all the temporaney files)		
  *WPS_PROCESSING_NAME: WPS Processing Name
  *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)
  *GRASS_LOG_FILE: File path for GRASS text LOG	(This File should contain all GRASS messages)
  *STATUS_FILE: File path for XML Status file (This XML File should contain the status information of the GRASS operation)		
 					 
 					 
  ***************************************************************************************************************************************-->
		
<!--		
  ********* Input TOOLBOX Variables ***************************************************************************************************

  *InputRaster: Local Path of Complex Value "InputRaster" defined by reference in the Execute Request. 
       (Input Description: Input raster file)
   
  *InputRaster_MimeType: Mime Type of "InputRaster" Input Complex Data. 
       (Mime Type Supported:  image/tiff  application/x-netcdf3  application/x-netcdf4  application/x-hdf  )
    
  *Band: Literal Datata "Band" Input value.
       (Input Description: 
 					The number of the band to be selected in the input raster file.
 					This band will be used to calculate the minimum, maximum, average, median, mode, standard deviation or sum (depending on the selected method).
 				)
       (Data Type: positiveInteger)
  *InputPolylines: Local Path of Complex Value "InputPolylines" defined by reference in the Execute Request. 
       (Input Description: Input polylines)
   
  *InputPolylines_MimeType: Mime Type of "InputPolylines" Input Complex Data. 
       (Mime Type Supported:  application/xml  )
    
  *Method: Literal Datata "Method" Input value.
       (Input Description: The operation to perform on the selected band of the input raster)
       (Allowed Values:  minimum  maximum  average  median  mode  stddev  sum  )
  *OrderId: Literal Datata "OrderId" Input value.
       (Input Description: OrderId (mandatory if Output = WMC))
       (Data Type: string)
  *Output_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "Output" Input.
       (Input Description: The output of the process)
       (Data Type: string)       (Allowed Values:  file  WMC  )
 					 
 					 
  ***************************************************************************************************************************************-->


<!--
  ********* Output TOOLBOX Variables *************************************************************************************************

  *OutputVector: Name of the file that will contain the "OutputVector" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
  *OutputVector_OUTPUT_PATH: Path of the file that will contain the "OutputVector" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputVector")
       (Output Description: Output vector file)
    
  *OutputVector_MimeType: OutputVector Output Mime Type (Mime type, for the OutputVector Complex Output, required in the Execute Request).
       (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  text/csv  application/xml  application/gpx+xml  application/vnd.google-earth.kml+xml  )
    
  *OutputWMC: Name of the file that will contain the "OutputWMC" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
  *OutputWMC_OUTPUT_PATH: Path of the file that will contain the "OutputWMC" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputWMC")
       (Output Description: WebMapContext file)
    
  *OutputWMC_MimeType: OutputWMC Output Mime Type (Mime type, for the OutputWMC Complex Output, required in the Execute Request).
       (Mime Type Supported:  text/xml  )
    
 					 
 					 
 ******************************************************************************************************************************-->


<!--  ------------------------------  TOOLBOX SCRIPT --------------------------------------------------------------------------------------------------------------------------------------->











                             <!--  Insert TOOLBOX Script-->














<!-- ------------------------------  END TOOLBOX SCRIPT -------------------------------------------------------------------------------------------------------------------------------->
  
