
	
#############################################################################
#
# $Id: execute_RasterResampling.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Resamples a raster file and stores the resulting raster file.
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory 
# *GENERAL_SERVICES_RESOURCES : General Services Resources Directory (This Folder contains all Toolbox services resources)
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains resources decicate service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)		
# *STATUS_FILE: File path for XML Status file		
		
#------Processing Variables	

# *InputRaster: Local Path of Complex Value "InputRaster" defined by reference in the Execute Request. 
#      (Input Description: Input raster file)
   
# *InputRaster_MimeType: Mime Type of "InputRaster" Input Complex Data. 
#      (Mime Type Supported:  image/tiff  application/x-netcdf3  application/x-netcdf4  application/x-hdf  )
    
# *InputRasterMetadata: Local Path of Complex Value "InputRasterMetadata" defined by reference in the Execute Request. 
#      (Input Description: Input raster metadata file)
   
# *InputRasterMetadata_MimeType: Mime Type of "InputRasterMetadata" Input Complex Data. 
#      (Mime Type Supported:  text/xml  )
    
# *Resolution: Literal Datata "Resolution" Input value.
#      (Input Description: The resolution to resample to  (in target georeferenced units and in both directions))
#      (Data Type: float)
# *ResamplingMethod: Literal Datata "ResamplingMethod" Input value.
#      (Input Description: 
#					The resampling method to use.
#					Available methods are:
#					near:
#						nearest neighbour resampling (default, fastest algorithm, worst interpolation quality). 
#					bilinear:
#						bilinear resampling. 
#					cubic:
#						cubic resampling. 
#					cubicspline:
#						cubic spline resampling. 
#					lanczos:
#						Lanczos windowed sinc resampling. 
#				)
#      (Allowed Values:  near  bilinear  cubic  cubicspline  lanczos  )
# *OutputDataType: Literal Datata "OutputDataType" Input value.
#      (Input Description: The data type of the raster output file)
#      (Allowed Values:  Byte  Int16  UInt16  UInt32  Int32  Float32  Float64  CInt16  CInt32  CFloat32  CFloat64  )
# *OutputRaster: File Name of the "OutputRaster" Complex Data Output.
#      (Output Description: Output raster file)
    
# *OutputRaster_MimeType: OutputRaster Output Mime Type.
#      (Mime Type Supported:  image/tiff  application/x-netcdf  application/x-hdf  image/png  image/jpeg  image/gif  )
    

#					 
#******************************************************************************************************************************


# ------------------------------  SHELL SCRIPT -------------------------------------------------------------------------------------------------------------------------------------











                              # Add your shell statements here














# ------------------------------  END SHELL SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  
