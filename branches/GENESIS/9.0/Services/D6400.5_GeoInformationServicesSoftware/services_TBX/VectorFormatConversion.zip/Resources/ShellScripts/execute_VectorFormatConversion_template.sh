
	
#############################################################################
#
# $Id: execute_VectorFormatConversion.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Convert a vector to another file format and stores the resulting vector file.
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory 
# *GENERAL_SERVICES_RESOURCES : General Services Resources Directory (This Folder contains all Toolbox services resources)
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains resources decicate service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)		
# *STATUS_FILE: File path for XML Status file		
		
#------Processing Variables	

# *InputVector: Local Path of Complex Value "InputVector" defined by reference in the Execute Request. 
#      (Input Description: 
#					Input vector file
#					The input vector file should be zipped!
#				)
   
# *InputVector_MimeType: Mime Type of "InputVector" Input Complex Data. 
#      (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  image/vdn.dgn  text/csv  application/xml  application/vnd.google-earth.kml+xml  )
    
# *OutputVector: File Name of the "OutputVector" Complex Data Output.
#      (Output Description: A ZIP file will be returned, containing the vector file in the requested file format)
    
# *OutputVector_MimeType: OutputVector Output Mime Type.
#      (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  text/csv  application/xml  application/gpx+xml  application/vnd.google-earth.kml+xml  )
    

#					 
#******************************************************************************************************************************


# ------------------------------  SHELL SCRIPT -------------------------------------------------------------------------------------------------------------------------------------











                              # Add your shell statements here














# ------------------------------  END SHELL SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  
