#!/bin/bash

checkStatus(){
	echo "Check Instance Status"
	PAUSEFILE=$OUTPUT_REPOSITORYPAUSED
	CANCELFILE=$OUTPUT_REPOSITORYCANCELED
	if [ -f $CANCELFILE ];
		then
			canceled
		else
			if [ -f $CANCELFILE ];
				then
					paused
				else
					echo "Not status changed"
				fi
		fi
}

resumed(){
	rm -f $OUTPUT_REPOSITORYPAUSED
	rm -f $OUTPUT_REPOSITORYPAUSED_OK
	echo "Instance Resumed"
	echo "RESUME RECEIVED" > $OUTPUT_REPOSITORY"RESUMED_OK"

}

paused(){
    rm -f $OUTPUT_REPOSITORY"RESUMED"
	rm -f $OUTPUT_REPOSITORY"RESUMED_OK"
	echo "Instance Paused"
	echo "PAUSE RECEIVED" > $OUTPUT_REPOSITORY"PAUSED_OK"
	RESUMEFILE=$OUTPUT_REPOSITORYRESUMED
	while [ ! -f $RESUMEFILE ]
		do
			sleep 10
		done
	
	resumed	
}

canceled(){
	rm -f $OUTPUT_REPOSITORYPAUSED
	rm -f $OUTPUT_REPOSITORYPAUSED_OK
	rm -f $OUTPUT_REPOSITORYRESUMED
	rm -f $OUTPUT_REPOSITORYRESUMED_OK
	echo "CANCEL RECEIVED" > $OUTPUT_REPOSITORY"CANCELED_OK"
	echo "Instance Deleted"
    exit 0
}

