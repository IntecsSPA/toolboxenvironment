
	
#############################################################################
#
# $Id: execute_Raster2VectorPolylinesIntersection.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Creates a vector map based on the intersection of a raster with a given set of polylines
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory 
# *GENERAL_SERVICES_RESOURCES : General Services Resources Directory (This Folder contains all Toolbox services resources)
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains resources decicate service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)		
# *STATUS_FILE: File path for XML Status file		
		
#------Processing Variables	

# *InputRaster: Local Path of Complex Value "InputRaster" defined by reference in the Execute Request. 
#      (Input Description: Input raster file)
   
# *InputRaster_MimeType: Mime Type of "InputRaster" Input Complex Data. 
#      (Mime Type Supported:  image/tiff  application/x-netcdf3  application/x-netcdf4  application/x-hdf  )
    
# *Band: Literal Datata "Band" Input value.
#      (Input Description: 
#					The number of the band to be selected in the input raster file.
#					This band will be used to calculate the minimum, maximum, average, median, mode, standard deviation or sum (depending on the selected method).
#				)
#      (Data Type: positiveInteger)
# *InputPolylines: Local Path of Complex Value "InputPolylines" defined by reference in the Execute Request. 
#      (Input Description: Input polylines)
   
# *InputPolylines_MimeType: Mime Type of "InputPolylines" Input Complex Data. 
#      (Mime Type Supported:  application/xml  )
    
# *Method: Literal Datata "Method" Input value.
#      (Input Description: The operation to perform on the selected band of the input raster)
#      (Allowed Values:  minimum  maximum  average  median  mode  stddev  sum  )
# *OrderId: Literal Datata "OrderId" Input value.
#      (Input Description: OrderId (mandatory if Output = WMC))
#      (Data Type: string)
# *Output_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "Output" Input.
#      (Input Description: The output of the process)
#      (Data Type: string)#      (Allowed Values:  file  WMC  )
# *OutputVector: File Name of the "OutputVector" Complex Data Output.
#      (Output Description: Output vector file)
    
# *OutputVector_MimeType: OutputVector Output Mime Type.
#      (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  text/csv  application/xml  application/gpx+xml  application/vnd.google-earth.kml+xml  )
    
# *OutputWMC: File Name of the "OutputWMC" Complex Data Output.
#      (Output Description: WebMapContext file)
    
# *OutputWMC_MimeType: OutputWMC Output Mime Type.
#      (Mime Type Supported:  text/xml  )
    

#					 
#******************************************************************************************************************************


# ------------------------------  SHELL SCRIPT -------------------------------------------------------------------------------------------------------------------------------------











                              # Add your shell statements here














# ------------------------------  END SHELL SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  
