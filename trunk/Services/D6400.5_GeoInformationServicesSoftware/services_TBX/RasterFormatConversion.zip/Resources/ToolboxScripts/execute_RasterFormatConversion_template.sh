
	


<!--                                                                 
 #############################################################################
 
  $Id: execute_RasterFormatConversion.sh,v    $
  UPDATED:	
 
  MODULE:   	TEST MODULE 
 
  AUTHOR(S):	Insert autors
                
  PURPOSE:  	Convert a raster to another file format and stores the resulting raster file.
 
  COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
  
 #############################################################################-->
                
                                                                              

<!--
  ********* External TOOLBOX Variables ************************************************************************************************
  -----WPS Service Varibles
  *OUTPUT_REPOSITORY : Output Repository Directory (This Folder should contain all the GRASS output files)
  *GENERAL_SERVICES_RESOURCES : Services General Resources Directory (This Folder contains general resources for all Toolbox services ).
  *SERVICE_RESOURCES : Service Resources Directory (This Folder contains only the resources of the current service)
  *TEMP_REPOSITORY : Temporaney Data created Repository Directory (This Folder should contain all the temporaney files)		
  *WPS_PROCESSING_NAME: WPS Processing Name
  *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)
  *GRASS_LOG_FILE: File path for GRASS text LOG	(This File should contain all GRASS messages)
  *STATUS_FILE: File path for XML Status file (This XML File should contain the status information of the GRASS operation)		
 					 
 					 
  ***************************************************************************************************************************************-->
		
<!--		
  ********* Input TOOLBOX Variables ***************************************************************************************************

  *InputRaster: Local Path of Complex Value "InputRaster" defined by reference in the Execute Request. 
       (Input Description: Input raster file)
   
  *InputRaster_MimeType: Mime Type of "InputRaster" Input Complex Data. 
       (Mime Type Supported:  image/tiff  application/x-netcdf3  application/x-netcdf4  application/x-hdf  )
    
  *InputRasterMetadata: Local Path of Complex Value "InputRasterMetadata" defined by reference in the Execute Request. 
       (Input Description: Input raster metadata file)
   
  *InputRasterMetadata_MimeType: Mime Type of "InputRasterMetadata" Input Complex Data. 
       (Mime Type Supported:  text/xml  )
    
  *Parameter_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "Parameter" Input.
       (Input Description: The parameter (dataset) to extract from a netCDF file containing muliple datasets)
       (Data Type: string)
  *SLD_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "SLD" Input.
       (Input Description: 
 					If output = WMC, this parameter is required (otherwise it will be ignored).
 					If no parameters are provided, you'll have to provide exactly 1 SLD file.
 					If parameters are provided, the number of supplied SLD's should be equal to the number of parameters.
 				)
       (Data Type: string)
  *GDALTranslateOptions: Literal Datata "GDALTranslateOptions" Input value.
       (Input Description: Additional option(s) that will be passed to the gdal_translate command)
       (Data Type: string)
  *LongitudeDataset: Literal Datata "LongitudeDataset" Input value.
       (Input Description: 
 					The name of the NetCDF dataset containing the longitude.
 					If you provide the LongitudeDataset, you should also provide the LatitudeDataset.
 				)
       (Data Type: string)
  *LatitudeDataset: Literal Datata "LatitudeDataset" Input value.
       (Input Description: 
 					The name of the NetCDF dataset containing the latitude.
 					If you provide the LatitudeDataset, you should also provide the LongitudeDataset.
 				)
       (Data Type: string)
  *Output_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "Output" Input.
       (Input Description: The output of the process)
       (Data Type: string)       (Allowed Values:  file  WMC  )
  *OutputDataType: Literal Datata "OutputDataType" Input value.
       (Input Description: The data type of the raster output file)
       (Allowed Values:  Byte  Int16  UInt16  UInt32  Int32  Float32  Float64  CInt16  CInt32  CFloat32  CFloat64  )
 					 
 					 
  ***************************************************************************************************************************************-->


<!--
  ********* Output TOOLBOX Variables *************************************************************************************************

  *OutputRaster: Name of the file that will contain the "OutputRaster" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
  *OutputRaster_OUTPUT_PATH: Path of the file that will contain the "OutputRaster" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputRaster")
       (Output Description: Output raster file)
    
  *OutputRaster_MimeType: OutputRaster Output Mime Type (Mime type, for the OutputRaster Complex Output, required in the Execute Request).
       (Mime Type Supported:  image/tiff  application/x-netcdf  application/x-hdf  image/png  image/jpeg  image/gif  )
    
  *OutputRasterMetadata: Name of the file that will contain the "OutputRasterMetadata" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
  *OutputRasterMetadata_OUTPUT_PATH: Path of the file that will contain the "OutputRasterMetadata" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputRasterMetadata")
       (Output Description: Output raster file)
    
  *OutputRasterMetadata_MimeType: OutputRasterMetadata Output Mime Type (Mime type, for the OutputRasterMetadata Complex Output, required in the Execute Request).
       (Mime Type Supported:  text/xml  )
    
  *OutputWMC: Name of the file that will contain the "OutputWMC" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
  *OutputWMC_OUTPUT_PATH: Path of the file that will contain the "OutputWMC" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputWMC")
       (Output Description: Web Map Context file containing references to Web Map Server instance)
    
  *OutputWMC_MimeType: OutputWMC Output Mime Type (Mime type, for the OutputWMC Complex Output, required in the Execute Request).
       (Mime Type Supported:  text/xml  )
    
 					 
 					 
 ******************************************************************************************************************************-->


<!--  ------------------------------  TOOLBOX SCRIPT --------------------------------------------------------------------------------------------------------------------------------------->











                             <!--  Insert TOOLBOX Script-->














<!-- ------------------------------  END TOOLBOX SCRIPT -------------------------------------------------------------------------------------------------------------------------------->
  
