
	
#!/bin/bash

#############################################################################
#
# $Id: execute_RasterOTBCoregistration.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Coregistration of a raster
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Environment Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory (This Folder should contain all the GRASS output files)
# *GENERAL_SERVICES_RESOURCES : Services General Resources Directory (This Folder contains general resources for all Toolbox services ).
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains only the resources of the current service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory (This Folder should contain all the temporaney files)		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)
# *GRASS_LOG_FILE: File path for GRASS text LOG	(This File should contain all GRASS messages)
# *STATUS_FILE: File path for XML Status file (This XML File should contain the status information of the GRASS operation)		
#					 
#					 
# ***************************************************************************************************************************************
		
		
# ********* Input Environment Variables ***************************************************************************************************

# *InputRaster: Local Path of Complex Value "InputRaster" defined by reference in the Execute Request. 
#      (Input Description: Input raster file)
   
# *InputRaster_MimeType: Mime Type of "InputRaster" Input Complex Data. 
#      (Mime Type Supported:  image/tiff  )
    
# *ReferenceRaster: Local Path of Complex Value "ReferenceRaster" defined by reference in the Execute Request. 
#      (Input Description: The reference raster file)
   
# *ReferenceRaster_MimeType: Mime Type of "ReferenceRaster" Input Complex Data. 
#      (Mime Type Supported:  image/tiff  )
    
# *PointStepX: Literal Datata "PointStepX" Input value.
#      (Input Description: Point Step X)
#      (Data Type: integer)
# *PointStepY: Literal Datata "PointStepY" Input value.
#      (Input Description: Point Step Y)
#      (Data Type: integer)
# *ExplorationSize: Literal Datata "ExplorationSize" Input value.
#      (Input Description: Exploration size)
#      (Data Type: integer)
# *WindowSize: Literal Datata "WindowSize" Input value.
#      (Input Description: Window size)
#      (Data Type: integer)
# *LearningRate: Literal Datata "LearningRate" Input value.
#      (Input Description: Learning rate)
#      (Data Type: integer)
# *NBIterations: Literal Datata "NBIterations" Input value.
#      (Input Description: NB iterations)
#      (Data Type: integer)
# *MetricThreshold: Literal Datata "MetricThreshold" Input value.
#      (Input Description: metric threshold)
#      (Data Type: float)
#					 
#					 
# ***************************************************************************************************************************************



# ********* Output Environment Variables *************************************************************************************************

# *OutputRaster: Name of the file that will contain the "OutputRaster" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
# *OutputRaster_OUTPUT_PATH: Path of the file that will contain the "OutputRaster" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputRaster")
#      (Output Description: Output raster file)
    
# *OutputRaster_MimeType: OutputRaster Output Mime Type (Mime type, for the OutputRaster Complex Output, required in the Execute Request).
#      (Mime Type Supported:  image/tiff  application/x-netcdf  application/x-hdf  image/png  image/jpeg  image/gif  )
    
# *FieldOutputRaster: Name of the file that will contain the "FieldOutputRaster" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
# *FieldOutputRaster_OUTPUT_PATH: Path of the file that will contain the "FieldOutputRaster" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "FieldOutputRaster")
#      (Output Description: Field output raster file)
    
# *FieldOutputRaster_MimeType: FieldOutputRaster Output Mime Type (Mime type, for the FieldOutputRaster Complex Output, required in the Execute Request).
#      (Mime Type Supported:  image/tiff  application/x-netcdf  application/x-hdf  image/png  image/jpeg  image/gif  )
    
#					 
#					 
#******************************************************************************************************************************


# ------------------------------  GRASS SCRIPT -------------------------------------------------------------------------------------------------------------------------------------



perl "$GENERAL_SERVICES_RESOURCES/scripts/rast_otb_coregistration.pl" \
--unique_code="$INSTANCE_VALUE" \
--input_raster="$InputRaster" \
--reference_raster="$ReferenceRaster" \
--point_step_x="$PointStepX" \
--point_step_y="$PointStepY" \
--exploration_size="$ExplorationSize" \
--window_size="$WindowSize" \
--learning_rate="$LearningRate" \
--nb_iterations="$NBIterations" \
--metric_threshold="$MetricThreshold" \
--output_raster="$OutputRaster_OUTPUT_PATH" \
--output_raster_mimetype="$OutputRaster_MimeType" \
--field_output_raster="$FieldOutputRaster_OUTPUT_PATH" \
--field_output_raster_mimetype="$FieldOutputRaster_MimeType"




# ------------------------------  END GRASS SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  

	
 # ------------------------------  OUTPUT MANAGER GRASS SCRIPT ------------------------------------------------------------------------------------------------------------------------------ 

     
     
              if [ -f "$OUTPUT_REPOSITORY$OutputRaster" ]; then 
                  echo "ComplexOutput "$OutputRaster" generated."
                  export ComplexOutputValueFile=$OUTPUT_REPOSITORY"OutputRaster.xml"
                  complexOutputControl="<?xml version=\"1.0\" encoding=\"UTF-8\"?><OutputGenerated>OK</OutputGenerated>"
                  echo $complexOutputControl >> $ComplexOutputValueFile
                  if [ "$RESPONSE_STORE" = "false"  -a "$OutputRaster_STORE" = "false" ]; then
                    export ComplexOutputValueFile=$OUTPUT_REPOSITORY"OutputRaster_Value.xml"
                    if [ "$OutputRaster_MimeType" != "text/xml" ]; then
                        complexOutputDocumentHeader="<?xml version=\"1.0\" encoding=\"UTF-8\"?><wps:Data xmlns:wps=\"http://www.opengis.net/wps/1.0.0\"><wps:ComplexData xmlns:ows=\"http://www.opengis.net/ows/1.1\">"
                        echo $complexOutputDocumentHeader >> $ComplexOutputValueFile
                        complexOutputDocumentFooter="</wps:ComplexData></wps:Data>"
                        if [ "$OutputRaster_GlobalType" = "BIN" ]; then
                              base64 $OUTPUT_REPOSITORY$OutputRaster >> $ComplexOutputValueFile
                          else
                              cat $OUTPUT_REPOSITORY$OutputRaster >> $ComplexOutputValueFile
                        fi
                        echo $complexOutputDocumentFooter >> $ComplexOutputValueFile
                      else
                       cat $OUTPUT_REPOSITORY$OutputRaster >> $ComplexOutputValueFile 
                    fi
                  fi
              else 
                  export ComplexOutputNULLFile=$OUTPUT_REPOSITORY"OutputRasterNULL.xml"
                  echo "Output "$OutputRaster" is NULL." >> $ComplexOutputNULLFile
                  echo "ComplexOutput "$OutputRaster" not generated."
              fi
              

            
              if [ -f "$OUTPUT_REPOSITORY$FieldOutputRaster" ]; then 
                  echo "ComplexOutput "$FieldOutputRaster" generated."
                  export ComplexOutputValueFile=$OUTPUT_REPOSITORY"FieldOutputRaster.xml"
                  complexOutputControl="<?xml version=\"1.0\" encoding=\"UTF-8\"?><OutputGenerated>OK</OutputGenerated>"
                  echo $complexOutputControl >> $ComplexOutputValueFile
                  if [ "$RESPONSE_STORE" = "false"  -a "$FieldOutputRaster_STORE" = "false" ]; then
                    export ComplexOutputValueFile=$OUTPUT_REPOSITORY"FieldOutputRaster_Value.xml"
                    if [ "$FieldOutputRaster_MimeType" != "text/xml" ]; then
                        complexOutputDocumentHeader="<?xml version=\"1.0\" encoding=\"UTF-8\"?><wps:Data xmlns:wps=\"http://www.opengis.net/wps/1.0.0\"><wps:ComplexData xmlns:ows=\"http://www.opengis.net/ows/1.1\">"
                        echo $complexOutputDocumentHeader >> $ComplexOutputValueFile
                        complexOutputDocumentFooter="</wps:ComplexData></wps:Data>"
                        if [ "$FieldOutputRaster_GlobalType" = "BIN" ]; then
                              base64 $OUTPUT_REPOSITORY$FieldOutputRaster >> $ComplexOutputValueFile
                          else
                              cat $OUTPUT_REPOSITORY$FieldOutputRaster >> $ComplexOutputValueFile
                        fi
                        echo $complexOutputDocumentFooter >> $ComplexOutputValueFile
                      else
                       cat $OUTPUT_REPOSITORY$FieldOutputRaster >> $ComplexOutputValueFile 
                    fi
                  fi
              else 
                  export ComplexOutputNULLFile=$OUTPUT_REPOSITORY"FieldOutputRasterNULL.xml"
                  echo "Output "$FieldOutputRaster" is NULL." >> $ComplexOutputNULLFile
                  echo "ComplexOutput "$FieldOutputRaster" not generated."
              fi
              

            
# ------------------------------  END OUTPUT MANAGER GRASS SCRIPT ----------------------------------------------------------------------------------------------------------------------------
  
