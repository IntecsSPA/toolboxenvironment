
	
#!/bin/bash

#############################################################################
#
# $Id: execute_RasterStatisticsPerBand.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Calculates the minimum, maximum or average of pixel values within (a) raster band(s)
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Environment Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory (This Folder should contain all the GRASS output files)
# *GENERAL_SERVICES_RESOURCES : Services General Resources Directory (This Folder contains general resources for all Toolbox services ).
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains only the resources of the current service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory (This Folder should contain all the temporaney files)		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)
# *GRASS_LOG_FILE: File path for GRASS text LOG	(This File should contain all GRASS messages)
# *STATUS_FILE: File path for XML Status file (This XML File should contain the status information of the GRASS operation)		
#					 
#					 
# ***************************************************************************************************************************************
		
		
# ********* Input Environment Variables ***************************************************************************************************

# *InputRaster: Local Path of Complex Value "InputRaster" defined by reference in the Execute Request. 
#      (Input Description: Input raster file)
   
# *InputRaster_MimeType: Mime Type of "InputRaster" Input Complex Data. 
#      (Mime Type Supported:  image/tiff  application/x-netcdf3  application/x-netcdf4  application/x-hdf  )
    
# *Band_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "Band" Input.
#      (Input Description: 
#					The band to be selected in the input raster file.
#					These band will be used to calculate the minimum, maximum or average (depending on the selected method).
#				)
#      (Data Type: positiveInteger)
# *Method_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "Method" Input.
#      (Input Description: 
#					The operation to perform on the selected bands of the input raster.
#					Unknown methods will be ignored.
#				)
#      (Allowed Values:  numberOfCells  numberOfNullCells  minimum  maximum  range  arithmeticMean  meanOfAbsoluteValues  standardDeviation  populationVariance  coefficientOfVariation  sum  firstQuartile  median  thirdQuartile  )
# *Parameter: Literal Datata "Parameter" Input value.
#      (Input Description: The parameter (dataset) to extract from a netCDF file containing muliple datasets)
#      (Data Type: string)
# *LongitudeDataset: Literal Datata "LongitudeDataset" Input value.
#      (Input Description: 
#					The name of the NetCDF dataset containing the longitude.
#					If you provide the LongitudeDataset, you should also provide the LatitudeDataset.
#				)
#      (Data Type: string)
# *LatitudeDataset: Literal Datata "LatitudeDataset" Input value.
#      (Input Description: 
#					The name of the NetCDF dataset containing the latitude.
#					If you provide the LatitudeDataset, you should also provide the LongitudeDataset.
#				)
#      (Data Type: string)
#					 
#					 
# ***************************************************************************************************************************************



# ********* Output Environment Variables *************************************************************************************************

# *Output: Name of the file that will contain the "Output" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
# *Output_OUTPUT_PATH: Path of the file that will contain the "Output" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "Output")
#      (Output Description: Results per band in GML 3.1.1 format)
    
# *Output_MimeType: Output Output Mime Type (Mime type, for the Output Complex Output, required in the Execute Request).
#      (Mime Type Supported:  text/xml  )
    
#					 
#					 
#******************************************************************************************************************************


# ------------------------------  GRASS SCRIPT -------------------------------------------------------------------------------------------------------------------------------------











                              # Insert GRASS Script














# ------------------------------  END GRASS SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  
