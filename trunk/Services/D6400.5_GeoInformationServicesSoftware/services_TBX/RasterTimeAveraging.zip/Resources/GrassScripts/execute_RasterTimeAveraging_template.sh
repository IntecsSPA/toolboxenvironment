
	
#!/bin/bash

#############################################################################
#
# $Id: execute_RasterTimeAveraging.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	A list of input rasters where each band of these rasters represents the values of a parameter at a certain elevation and at a certain time has to be provided.
#		A new band is created by averaging the pixel values of the bands at a provided elevation over a certain time period. The starting time and period are provided and the averages are calculated for every (x * [Period]) + [StartTime]) -period until all bands of the input rasters are processed.
#		The resulting raster will contain all resulting bands containing the averaged pixel values.
#		
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Environment Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory (This Folder should contain all the GRASS output files)
# *GENERAL_SERVICES_RESOURCES : Services General Resources Directory (This Folder contains general resources for all Toolbox services ).
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains only the resources of the current service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory (This Folder should contain all the temporaney files)		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)
# *GRASS_LOG_FILE: File path for GRASS text LOG	(This File should contain all GRASS messages)
# *STATUS_FILE: File path for XML Status file (This XML File should contain the status information of the GRASS operation)		
#					 
#					 
# ***************************************************************************************************************************************
		
		
# ********* Input Environment Variables ***************************************************************************************************

# *InputRaster_MULTIPLE_INPUT_FOLDER: (Folder that contains the multiple Complex Value "InputRaster" Input defined by reference in the Execute Request.)
#      (Input Description: Input raster file)
   
# *InputRaster_MULTIPLE_INPUT_MimeType: Mime Types List separted from ',' for the multiple "InputRaster" Complex Data. 
#      (Each value correspond at the Mime Type of the file, called like the list position of the Mime Type value, in the "InputRaster_MULTIPLE_INPUT_FOLDER" folder)
#      (Supported:  application/x-netcdf3  application/x-netcdf4  )
    
# *InputRasterMetadata_MULTIPLE_INPUT_FOLDER: (Folder that contains the multiple Complex Value "InputRasterMetadata" Input defined by reference in the Execute Request.)
#      (Input Description: Input raster metadata file)
   
# *InputRasterMetadata_MULTIPLE_INPUT_MimeType: Mime Types List separted from ',' for the multiple "InputRasterMetadata" Complex Data. 
#      (Each value correspond at the Mime Type of the file, called like the list position of the Mime Type value, in the "InputRasterMetadata_MULTIPLE_INPUT_FOLDER" folder)
#      (Supported:  text/xml  )
    
# *Elevation: Literal Datata "Elevation" Input value.
#      (Input Description: The elevation in meters for which the parameters are to be extracted from the netCDF files)
#      (Data Type: integer)
# *Elevation_UOM: Unit of Measure of "Elevation" Literal Data. 
#      (Supported:  meters  )

    
# *StartPeriod: Literal Datata "StartPeriod" Input value.
#      (Input Description: The first date over which the averaging takes place)
#      (Data Type: date)
# *EndPeriod: Literal Datata "EndPeriod" Input value.
#      (Input Description: The last date over which the averaging takes place)
#      (Data Type: date)
# *AveragingWindow: Literal Datata "AveragingWindow" Input value.
#      (Input Description: The window specified in days for which the average has to be calculated)
#      (Data Type: positiveInteger)
# *AveragingWindow_UOM: Unit of Measure of "AveragingWindow" Literal Data. 
#      (Supported:  days  )

    
# *StartHour: Literal Datata "StartHour" Input value.
#      (Input Description: The fist hour of a day to take into account to calculate the average for that day)
#      (Data Type: positiveInteger)#      (Allowed Values:  )
# *StartHour_UOM: Unit of Measure of "StartHour" Literal Data. 
#      (Supported:  hours  )

    
# *EndHour: Literal Datata "EndHour" Input value.
#      (Input Description: The last hour of a day to take into account to calculate the average for that day)
#      (Data Type: positiveInteger)#      (Allowed Values:  )
# *EndHour_UOM: Unit of Measure of "EndHour" Literal Data. 
#      (Supported:  hours  )

    
# *OutputDataType: Literal Datata "OutputDataType" Input value.
#      (Input Description: The data type of the raster output file)
#      (Allowed Values:  Byte  Int16  UInt16  UInt32  Int32  Float32  Float64  CInt16  CInt32  CFloat32  CFloat64  )
#					 
#					 
# ***************************************************************************************************************************************



# ********* Output Environment Variables *************************************************************************************************

# *OutputRaster: Name of the file that will contain the "OutputRaster" Complex Data Output. (This file must be saved in theOutput Repository Folder. This folder is defined by the environment variable OUTPUT_REPOSITORY)
# *OutputRaster_OUTPUT_PATH: Path of the file that will contain the "OutputRaster" Complex Data Output. (This PATH is obtained from the concatenation of the environment variable "OUTPUT_REPOSITORY" and the the environment variable "OutputRaster")
#      (Output Description: The output raster file)
    
# *OutputRaster_MimeType: OutputRaster Output Mime Type (Mime type, for the OutputRaster Complex Output, required in the Execute Request).
#      (Mime Type Supported:  image/tiff  application/x-netcdf  application/x-hdf  image/png  image/jpeg  image/gif  )
    
# *OutputTimestampsInBands: This environment variable will contain the value for "OutputTimestampsInBands" Literal Data Output.
#      (Output Description: A comma seperated list of timestamps that correspond to the different bands of the OutputRaster)
#      (Data Type: string)
#					 
#					 
#******************************************************************************************************************************


# ------------------------------  GRASS SCRIPT -------------------------------------------------------------------------------------------------------------------------------------











                              # Insert GRASS Script














# ------------------------------  END GRASS SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  
