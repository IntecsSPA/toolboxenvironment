
	
#############################################################################
#
# $Id: execute_VectorSelection.sh,v    $
# UPDATED:	
#
# MODULE:   	TEST MODULE 
#
# AUTHOR(S):	Insert autors
#               
# PURPOSE:  	Selects features from a vector file (InputVector1) that overlap with features from another vector file (InputVector2) and stores the resulting vector file.
#
# COPYRIGHT: (C) 2009 Intecs Informatica e tecnologia del Software SpA 
#
#               
#############################################################################

# ********* External Variables ************************************************************************************************
# -----WPS Service Varibles
# *OUTPUT_REPOSITORY : Output Repository Directory 
# *GENERAL_SERVICES_RESOURCES : General Services Resources Directory (This Folder contains all Toolbox services resources)
# *SERVICE_RESOURCES : Service Resources Directory (This Folder contains resources decicate service)
# *TEMP_REPOSITORY : Temporaney Data created Repository Directory		
# *WPS_PROCESSING_NAME: WPS Processing Name
# *INSTANCE_VALUE: Instance Operation Value (for multiple Instances)		
# *STATUS_FILE: File path for XML Status file		
		
#------Processing Variables	

# *InputVector1: Local Path of Complex Value "InputVector1" defined by reference in the Execute Request. 
#      (Input Description: 
#					The input vector file where the selection will occur upon
#					If the input vector file is a ESRI Shapefile, it should be zipped!
#				)
   
# *InputVector1_MimeType: Mime Type of "InputVector1" Input Complex Data. 
#      (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  image/vdn.dgn  text/csv  application/xml  application/vnd.google-earth.kml+xml  )
    
# *InputVector2: Local Path of Complex Value "InputVector2" defined by reference in the Execute Request. 
#      (Input Description: 
#					The vector file that will be used to overlap InputVector1
#					If the input vector file is a ESRI Shapefile, it should be zipped!
#				)
   
# *InputVector2_MimeType: Mime Type of "InputVector2" Input Complex Data. 
#      (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  image/vdn.dgn  text/csv  application/xml  application/vnd.google-earth.kml+xml  )
    
# *OutputType_MULTIPLE_LITERAL_LIST: Values List separted from ',' that contains the multiple Literal Value "OutputType" Input.
#      (Input Description: 
#					Feature types to export.
#					Note: A combination of types is not supported by all formats.
#					Default: line, boundary
#				)
#      (Allowed Values:  point  kernel  centroid  line  boundary  area  face  )
# *OutputVector: File Name of the "OutputVector" Complex Data Output.
#      (Output Description: A ZIP file will be returned, containing the vector file in the requested file format)
    
# *OutputVector_MimeType: OutputVector Output Mime Type.
#      (Mime Type Supported:  application/x-esri-shapefile  application/x-mapinfo-mif-mid  text/csv  application/xml  application/gpx+xml  application/vnd.google-earth.kml+xml  )
    

#					 
#******************************************************************************************************************************


# ------------------------------  SHELL SCRIPT -------------------------------------------------------------------------------------------------------------------------------------











                              # Add your shell statements here














# ------------------------------  END SHELL SCRIPT ------------------------------------------------------------------------------------------------------------------------------
  
